# @firebase/app

This package coordinates the communication between the different Firebase components and
exposes the API surface to the user

**This package is not intended for direct usage, and should only be used via the officially supported [firebase](https://www.npmjs.com/package/firebase) package.**
