# Installation
> `npm install --save @types/express-jwt`

# Summary
This package contains type definitions for express-jwt ( https://www.npmjs.org/package/express-jwt ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express-jwt

Additional Details
 * Last updated: Tue, 19 Mar 2019 23:48:06 GMT
 * Dependencies: @types/express, @types/express-unless
 * Global values: none

# Credits
These definitions were written by  Wonshik Kim <https://github.com/wokim>, Kacper Polak <https://github.com/kacepe>, Sl1MBoy <https://github.com/Sl1MBoy>, Milan Mimra <https://github.com/milan-mimra>.
