# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

# 1.0.0 (2020-02-18)


### Features

* fork asn1.js, remove all dependencies, use BigInt instead bn.js ([6d3c518](https://github.com/panva/asn1.js/commit/6d3c5188af42059478f8833b768912cb7b86aceb))
